const fileinclude = require('gulp-file-include');

gulp.task('html', function() {
    return gulp.src(['*.html', '!components/**'])
        .pipe(fileinclude({
            prefix: '@@',
            basepath: '@file'
        }))
        .pipe(gulp.dest('./dist'));
}); 