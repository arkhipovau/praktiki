document.addEventListener('DOMContentLoaded', function() {
    console.log('Script loaded'); // Проверка загрузки скрипта

    const filterButtons = document.querySelectorAll('.filter-tag');
    const storyCards = document.querySelectorAll('.main-story-card');

    console.log('Filter buttons:', filterButtons.length); // Проверка количества кнопок
    console.log('Story cards:', storyCards.length); // Проверка количества карточек

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            console.log('Button clicked:', button.getAttribute('data-filter')); // Проверка клика

            // Убираем активный класс у всех кнопок
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Добавляем активный класс нажатой кнопке
            button.classList.add('active');

            const filterValue = button.getAttribute('data-filter');

            storyCards.forEach(card => {
                if (filterValue === 'all') {
                    card.style.display = 'flex';
                } else {
                    if (card.getAttribute('data-category') === filterValue) {
                        card.style.display = 'flex';
                    } else {
                        card.style.display = 'none';
                    }
                }
            });
        });
    });
}); 