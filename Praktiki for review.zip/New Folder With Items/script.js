// Добавляем JavaScript для работы мобильного меню
document.addEventListener('DOMContentLoaded', function() {
    const menuButton = document.querySelector('.mobile-menu-button');
    const headerNav = document.querySelector('.header-nav');
    
    menuButton.addEventListener('click', function() {
        headerNav.classList.toggle('active');
        menuButton.classList.toggle('mobile-menu-open');
    });
}); 